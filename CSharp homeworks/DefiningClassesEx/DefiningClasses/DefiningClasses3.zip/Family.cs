﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DefiningClasses
{
    public class Family
    {
        public Family()
        {
            listPeople = new List<Person>();
        }
        public List<Person> listPeople { get; set; }

        public void AddMember (Person person)
        {
            listPeople.Add(person);
        }

        public Person GetOldestMember()
        {
            var oldest = listPeople.OrderByDescending(x => x.Age).ToList();

            return oldest[0]; 
        }
    }
}
