﻿using System;

namespace DefiningClasses
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            Person person = new Person();
            person.Age = 20;
            person.Name = "Pesho";

            Console.WriteLine(person.Age);
            Console.WriteLine(person.Name);

        }
    }
}
