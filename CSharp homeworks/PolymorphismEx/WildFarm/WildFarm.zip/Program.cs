﻿using System;
using WildFarm.Core;
using WildFarm.Models;

namespace WildFarm
{
    class Program
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
