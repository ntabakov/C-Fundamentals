﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm.Common
{
    public static  class Messages
    {
        public const string WrongAnimalFood = "{0} does not eat {1}!";
        
    }
}
