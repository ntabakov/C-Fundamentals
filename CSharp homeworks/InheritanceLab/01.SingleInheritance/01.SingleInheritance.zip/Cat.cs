﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _01.SingleInheritance
{
    class Cat : Animal
    {
        public void Meow() 
        {
            Console.WriteLine("meowing...");
        }
    }
}
